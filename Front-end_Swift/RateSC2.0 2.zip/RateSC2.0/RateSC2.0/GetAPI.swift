//
//  RestAPI.swift
//  RateSC
//
//  Created by Jeff Santelli on 4/7/20.
//  Copyright © 2020 Jeff Santelli. All rights reserved.
//

import Foundation

//: Playground - noun: a place where people can play

// From That Thing in Swift
// https://thatthinginswift.com

import UIKit

//func fetchCategories() {
//    print("fetch")
//    let session = URLSession.shared
//    let url = URL(string: "http://localhost:8080/RateSCAPI/restapi/GetCategories")!
//    let task = session.dataTask(with: url) { data, response, error in
//        if error != nil || data == nil {
//            print("Client error!")
//            return
//        }
//        do {
//            let json = try JSONSerialization.jsonObject(with: data!, options:[])
//            print(json)
//
//        }catch {
//            print("JSON ERROR")
//        }
//    };task.resume()
//}

//func fetchRatedObjectByCategory(CategoryID: Int, completion:@escaping (Result<[Category], Error>) -> ()) {
//    let session = URLSession.shared
//    guard let url = URL( string: "http://localhost:8080/RateSCAPI/restapi/RatedObjectByCategory/" + String(CategoryID)) else {return}
//    let task = session.dataTask(with: url, completionHandler: { (data, response, error) in
////    guard let data = data , error == nil else {return}
//        if let error = error {
//            completion(.failure(error))
//            return
//        }
//        do {
//            self.items = try JSONDecoder().decode([Category].self, from: data!)
//            completion(.success(RatedObjects))
//            self.tableView.reloadData()
//            } catch let jsonError{
//                print("Error")
//            }
//    });task.resume()
//}

func fetchRatedObjectBySearch(Search: String){
    let session = URLSession.shared
    let jsonURL = "http://localhost:8080/RateSCAPI/restapi/RatedObjectBySearch/" +  String(Search)
    guard let url = URL( string: jsonURL) else {return}
    let task = session.dataTask(with: url, completionHandler: { (data, response, error) in
    guard let data = data , error == nil else {return}
        do {
            let items = try JSONDecoder().decode([Category].self, from: data)
        } catch {
            print("Error")
        }
    });task.resume()
}

//var CategoryName = "Classes"
////fetchCategories()
//fetchRatedObjectByCategory(CategoryName: "Classes")
