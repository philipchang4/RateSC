//
//  CategoryItemTableViewController.swift
//  RateSC2.0
//
//  Created by Susan Jensen on 4/18/20.
//  Copyright © 2020 USC. All rights reserved.
//

import UIKit

class CategoryItemsTableViewController: UITableViewController {
    var titleName : String = "Classes"
    
    @IBOutlet weak var titleCategory: UILabel!
    
    var valueToPass : Category = Category(name: "", avgRating: 5, RatedObjectID: 1, listRatings: [Rating(ratedObjectID: 1, description: "", dateCreated: "", ID: 1, numLikes: 1, rating: 1, privacy: true)])
    
    var ID : Int = 0
    var items = [Category]()
    var isntGuest : DarwinBoolean = true
    
    func set (results:[Category]) {
        items = results
    }
    @IBAction func backButton(_ sender: Any) {
        self.performSegue(withIdentifier: "backHome", sender: self)
    }
    
    
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let indexPath = tableView.indexPathForSelectedRow!
        let currentCell = tableView.cellForRow(at: indexPath)! as! CategoryItemsTableViewCell

        print("HIT")
        
        valueToPass = currentCell.catTotal
        //print(valueToPass)
        self.performSegue(withIdentifier: "loadRev", sender: self)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?){

        if (segue.identifier == "loadRev") {
            print("loading")
            // initialize new view controller and cast it as your view controller
            let viewController = segue.destination as! ReviewTableViewController
             //your new view controller should have property that will store passed value
            viewController.cate = valueToPass
            print(viewController.cate)
            if(isntGuest == false)
            {
                viewController.notGuest = false
            }
        }
    }
    
    public  func loadTemp()
    {
//        let testR = [Rating(ratedObjectID: 2, description: "test", dateCreated: "test", ID: 2, numLikes: 2, rating: 5, privacy: true)]
//        var cat = Category(name: "test", avgRating: 5, RatedObjectID: 3, listRatings: testR)
//        items += [cat]
//
//        let session = URLSession.shared
//        let jsonURL = "http://localhost:8080/RateSCAPI/restapi/RatedObjectByCategory/" +  String(ID)
//        guard let url = URL( string: jsonURL) else {return}
//        let task = session.dataTask(with: url, completionHandler: { (data, response, error) in
//        guard let data = data , error == nil else {return}
//            do {
//                  let RatedObjects = try JSONDecoder().decode([Category].self, from: data)
//                  for ro in RatedObjects {
//                    items += [ro]
//                      print(ro.name)
//                  }
//                  //print(items.count)
////                //self.tableView.reloadData()
//            } catch {
//                print("Error")
//            }
//        });task.resume()
            let session = URLSession.shared
            let jsonURL = "http://localhost:8080/RateSCAPI/restapi/RatedObjectByCategory/" +  String(ID)
            guard let url = URL( string: jsonURL) else {return}
            let task = session.dataTask(with: url, completionHandler: { (data, response, error) in
            guard let data = data , error == nil else {return}
                do {
                    self.items = try JSONDecoder().decode([Category].self, from: data)
                    print(self.items)
                    self.tableView.reloadData()
                    } catch {
                        print("Error")
                    }
            });task.resume()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        titleCategory.text = titleName
        
        loadTemp()
        
        tableView.allowsSelection = true
        print("allowed")
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(items.count)
        return items.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "CategoryItemsTableViewCell"
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? CategoryItemsTableViewCell  else {
            fatalError("The dequeued cell is not an instance of CategoryTableViewCell.")
        }
        
        let ratedObj = items[indexPath.row]
        print(ratedObj.name)
        print(cell.nameLabel)
        print(cell.listReviews)
        print(cell.valueRating)
        cell.nameLabel.text = ratedObj.name
        cell.listReviews = ratedObj.listRatings
        let par = String(ratedObj.avgRating)
        cell.valueRating.text = par
        cell.catTotal = ratedObj
        return cell
    }
    
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
