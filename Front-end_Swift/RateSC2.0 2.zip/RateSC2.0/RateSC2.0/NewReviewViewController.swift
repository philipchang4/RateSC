//
//  NewReviewViewController.swift
//  RateSC2.0
//
//  Created by Susan Jensen on 4/25/20.
//  Copyright © 2020 USC. All rights reserved.
//

import UIKit

class NewReviewViewController: UIViewController {

    //MARK: Properties
    
    var categ : Category = Category(name: "", avgRating: 5, RatedObjectID: 1, listRatings: [Rating(ratedObjectID: 1, description: "", dateCreated: "", ID: 1, numLikes: 1, rating: 1, privacy: true)])
    
    @IBOutlet weak var objTitle: UILabel!
    
    @IBOutlet weak var ratingItem: UISlider!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var descripReview: UITextField!
    
    @IBAction func Slider(_ sender: Any) {
        let currentValue = Int(ratingItem.value)
            
        label.text = "\(currentValue)"
    }
    
    @IBAction func submitButton(_ sender: Any)
    {
        let session = URLSession.shared
        var jsonURL = "http://localhost:8080/RateSCAPI/restapi/AddRating/" + String(3)
        jsonURL = jsonURL + "/"
        jsonURL = jsonURL + String(categ.RatedObjectID)
        jsonURL = jsonURL + "/"
        jsonURL = jsonURL + String(descripReview.text ?? "")
        jsonURL = jsonURL + "/"
        jsonURL = jsonURL + String(ratingItem.value)
        jsonURL = jsonURL + "/false"
        guard let url = URL( string: jsonURL) else {return}
        let task = session.dataTask(with: url, completionHandler: { (data, response, error) in
        guard let data = data , error == nil else {return}
//            do {
//                let rating = try JSONDecoder().decode([Category].self, from: data)
//                } catch {
//                    print("Error")
//                }
        });task.resume()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        descripReview.text = ""
        ratingItem.value = 5
        objTitle.text = categ.name
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
