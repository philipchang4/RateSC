//
//  HomeViewController.swift
//  RateSC2.0
//
//  Created by Susan Jensen on 4/26/20.
//  Copyright © 2020 USC. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    @IBOutlet weak var classes: UIButton!
    @IBOutlet weak var professors: UIButton!
    @IBOutlet weak var studentorgs: UIButton!
    @IBOutlet weak var events: UIButton!
    @IBOutlet weak var restaurants: UIButton!
    @IBOutlet weak var dorm: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func Professors(_ sender: Any) { //2
        self.performSegue(withIdentifier: "viewcat2", sender: self)
    }
    
    @IBAction func Dorms(_ sender: Any) { //6
        self.performSegue(withIdentifier: "viewcat6", sender: self)
    }
    
    @IBAction func Events(_ sender: Any) { //5
        self.performSegue(withIdentifier: "viewcat5", sender: self)
    }
    
    @IBAction func StudentOrgs(_ sender: Any) { //4
        self.performSegue(withIdentifier: "viewcat4", sender: self)
    }
    
    
    @IBAction func Restaurants(_ sender: Any) { //1
        self.performSegue(withIdentifier: "viewcat", sender: self)
    }
    
    @IBAction func classes(_ sender: Any) //3
    {
        self.performSegue(withIdentifier: "viewcat3", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.identifier == "viewcat"
        {
            let vc = segue.destination as? CategoryItemsTableViewController
            vc?.titleName = "Restaurants"
            vc?.ID = 1
        }
        if segue.identifier == "viewcat2"
        {
            let vc = segue.destination as? CategoryItemsTableViewController
            vc?.titleName = "Professors"
            vc?.ID = 2
        }
        if segue.identifier == "viewcat3"
        {
            let vc = segue.destination as? CategoryItemsTableViewController
            vc?.titleName = "Classes"
            vc?.ID = 3
        }
        if segue.identifier == "viewcat4"
        {
            let vc = segue.destination as? CategoryItemsTableViewController
            vc?.titleName = "Student Clubs"
            vc?.ID = 4
        }
        if segue.identifier == "viewcat5"
        {
            let vc = segue.destination as? CategoryItemsTableViewController
            vc?.titleName = "Events"
            vc?.ID = 5
        }
        if segue.identifier == "viewcat6"
        {
            let vc = segue.destination as? CategoryItemsTableViewController
            vc?.titleName = "Dorms"
            vc?.ID = 6
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
