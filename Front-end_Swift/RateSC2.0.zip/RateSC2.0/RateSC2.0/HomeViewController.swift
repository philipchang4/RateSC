//
//  HomeViewController.swift
//  RateSC2.0
//
//  Created by Susan Jensen on 4/26/20.
//  Copyright © 2020 USC. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    @IBOutlet weak var classes: UIButton!
    @IBOutlet weak var professors: UIButton!
    @IBOutlet weak var studentorgs: UIButton!
    @IBOutlet weak var events: UIButton!
    @IBOutlet weak var restaurants: UIButton!
    @IBOutlet weak var dorm: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func classes(_ sender: Any) {
       
        let vc = CategoryItemsTableViewController(nibName: "CategoryItemsTableViewController", bundle: nil)
        vc.titleName = "Classes"

        self.performSegue(withIdentifier: "viewcat", sender: self)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
