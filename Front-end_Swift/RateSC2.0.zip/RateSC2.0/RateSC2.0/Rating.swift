//
//  Rating.swift
//  RateSC2.0
//
//  Created by Susan Jensen on 4/26/20.
//  Copyright © 2020 USC. All rights reserved.
//

import UIKit

class Rating: NSObject {
    var ratedObjectID : Int
    var descriptionRating: String
    var date : String
    var ID : Int
    var numLikes : Int
    var rat : Double
    var privacy : Bool
    
    init(ratedObjectID:Int, descriptionRating:String, date:String, ID:Int, numLikes:Int, rat:Double, privacy:Bool)
    {
        self.ratedObjectID = ratedObjectID
        self.descriptionRating = descriptionRating
        self.date = date
        self.ID = ID
        self.numLikes = numLikes
        self.rat = rat
        self.privacy = privacy
    }

}
