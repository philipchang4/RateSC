//
//  NewReviewViewController.swift
//  RateSC2.0
//
//  Created by Susan Jensen on 4/25/20.
//  Copyright © 2020 USC. All rights reserved.
//

import UIKit

class NewReviewViewController: UIViewController {

    //MARK: Properties
    
    var categ : Category = Category(name: "", avgRating: 5, RatedObjectID: 1, listRatings: [Rating(ratedObjectID: 1, description: "", dateCreated: "", ID: 1, numLikes: 1, rating: 1, privacy: true)])
    
    @IBOutlet weak var objTitle: UILabel!
    
    @IBOutlet weak var ratingItem: UISlider!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var descripReview: UITextField!
    
    @IBAction func Slider(_ sender: Any) {
        let currentValue = Int(ratingItem.value)
            
        label.text = "\(currentValue)"
    }
    
    @IBAction func submitButton(_ sender: Any)
    {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        descripReview.text = ""
        ratingItem.value = 5
        objTitle.text = categ.name
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
