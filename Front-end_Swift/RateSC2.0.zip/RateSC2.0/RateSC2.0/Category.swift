//
//  Category.swift
//  RateSC2.0
//
//  Created by Susan Jensen on 4/18/20.
//  Copyright © 2020 USC. All rights reserved.
//

import UIKit

struct Category: Decodable
{
    //var cat: String
    let name: String
    let avgRating: Double
    let RatedObjectID: Int
    let listRatings : [Rating]
    
    
}
