//
//  RevTableViewCell.swift
//  
//
//  Created by Philip Chang on 4/29/20.
//

import UIKit

class RevTableViewCell: UITableViewCell {

    
    @IBOutlet weak var rReview: UILabel!
    @IBOutlet weak var dReview: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
