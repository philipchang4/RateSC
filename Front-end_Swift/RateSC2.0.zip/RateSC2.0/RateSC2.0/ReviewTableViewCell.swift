//
//  ReviewTableViewCell.swift
//  RateSC2.0
//
//  Created by Philip Chang on 4/28/20.
//  Copyright © 2020 USC. All rights reserved.
//

import UIKit

class ReviewTableViewCell: UITableViewCell {

//    @IBOutlet weak var descripRev: UILabel!
//    @IBOutlet weak var ratingRev: UILabel!
    
    
    @IBOutlet weak var descriptionCell: UILabel!
    
    @IBOutlet weak var ratingCell: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
