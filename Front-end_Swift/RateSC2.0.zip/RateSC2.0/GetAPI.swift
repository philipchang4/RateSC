//
//  GetAPI.swift
//  RateSC2.0
//
//  Created by Susan Jensen on 4/26/20.
//  Copyright © 2020 USC. All rights reserved.
//

import Foundation
