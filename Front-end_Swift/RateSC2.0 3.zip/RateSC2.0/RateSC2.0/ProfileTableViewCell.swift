//
//  ProfileTableViewCell.swift
//  RateSC2.0
//
//  Created by Philip Chang on 4/29/20.
//  Copyright © 2020 USC. All rights reserved.
//

import UIKit



class ProfileTableViewCell: UITableViewCell {
    @IBOutlet weak var desRev: UILabel!
    
    @IBOutlet weak var ratRev: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
