//
//  CategoryFeed.swift
//  RateSC2.0
//
//  Created by Susan Jensen on 4/21/20.
//  Copyright © 2020 USC. All rights reserved.
//

import UIKit

class CategoryFeed: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
