//
//  Rating.swift
//  RateSC2.0
//
//  Created by Susan Jensen on 4/26/20.
//  Copyright © 2020 USC. All rights reserved.
//

import UIKit

struct Rating: Decodable {
    let ratedObjectID : Int
    let description: String
    let dateCreated : String
    let ID : Int
    let numLikes : Int
    let rating : Double
    let privacy : Bool
    
//    init(ratedObjectID:Int, descriptionRating:String, date:String, ID:Int, numLikes:Int, rat:Double, privacy:Bool)
//    {
//        self.ratedObjectID = ratedObjectID
//        self.descriptionRating = descriptionRating
//        self.date = date
//        self.ID = ID
//        self.numLikes = numLikes
//        self.rat = rat
//        self.privacy = privacy
//    }

}
